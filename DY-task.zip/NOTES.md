## Assumptions:
- we don’t have to keep and restore the state of open/closed content area globally
- if it’s completely standalone plugin in could be handled with react portals